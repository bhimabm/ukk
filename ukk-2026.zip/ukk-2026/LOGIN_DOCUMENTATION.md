# Sistem Login - Dokumentasi

## Deskripsi
Sistem login untuk **Sistem Pengaduan** yang telah diintegrasikan dengan database `ukk-bhima`. Sistem ini mendukung dua tipe pengguna: **Admin** dan **Siswa**.

## File yang Telah Dibuat

### 1. Controller
- **`app/Http/Controllers/AuthController.php`**
  - Menangani proses login, logout
  - Validasi kredensial pengguna
  - Session management

### 2. Views (Blade Templates)
- **`resources/views/auth/login.blade.php`**
  - Halaman login dengan UI yang responsif
  - Support untuk error handling dan validasi

- **`resources/views/dashboard.blade.php`**
  - Halaman dashboard setelah login
  - Menampilkan informasi user
  - Navigasi berdasarkan tipe pengguna (Admin/Siswa)

- **`resources/views/welcome.blade.php`**
  - Halaman utama/beranda
  - Tombol untuk menuju halaman login

### 3. Database
- **`database/migrations/2024_02_10_000003_add_columns_to_users_table.php`**
  - Migration untuk menambahkan kolom `nis`, `kelas`, `is_admin` ke tabel users

### 4. Routes
- **`routes/web.php`** - Updated
  - Route login (GET/POST)
  - Route dashboard
  - Route logout

### 5. Model
- **`app/Models/User.php`** - Updated
  - Tambahan fillable fields: `nis`, `kelas`, `is_admin`

## Setup & Installation

### 1. Jalankan Migration
```bash
php artisan migrate
```

### 2. Database Seeder (Optional)
Data pengguna sudah ada di database dari `ukk-bhima.sql`:

**Akun Admin:**
- Email: `admin@app.com`
- Password: `password`

**Akun Siswa 1:**
- Email: `siswa@app.com`
- Password: `password`

**Akun Siswa 2:**
- Email: `siswa2@app.com`
- Password: `password`

### 3. Konfigurasi Environment (.env)
Pastikan `.env` sudah dikonfigurasi dengan benar:
```
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=ukk-bhima
DB_USERNAME=root
DB_PASSWORD=
```

### 4. Jalankan Development Server
```bash
php artisan serve
```

Server akan berjalan di: `http://localhost:8000`

## Routes yang Tersedia

| Method | Route | Nama | Middleware | Deskripsi |
|--------|-------|------|-----------|-----------|
| GET | `/` | home | - | Redirect ke login jika belum auth |
| GET | `/login` | login | guest | Tampilkan form login |
| POST | `/login` | login | guest | Proses login |
| GET | `/dashboard` | dashboard | auth | Halaman dashboard |
| POST | `/logout` | logout | auth | Proses logout |

## Fitur

### Login Page
- ✅ Form email dan password
- ✅ Validasi input (email format, password minimum 6 karakter)
- ✅ Error handling dengan pesan yang jelas
- ✅ Design responsif dan modern
- ✅ Tampilkan kredensial uji coba

### Dashboard Page
- ✅ Greeting dengan nama pengguna
- ✅ Tampilkan informasi user (email, NIS, kelas, tipe akun)
- ✅ Logout button
- ✅ Menu berbeda berdasarkan tipe akun (Admin/Siswa)
- ✅ Design responsif dan modern

### Security
- ✅ Password hashing dengan bcrypt
- ✅ CSRF protection
- ✅ Session management
- ✅ Middleware authentication untuk protected routes
- ✅ Middleware guest untuk login routes

## Struktur Database (dari ukk-bhima.sql)

```sql
CREATE TABLE users (
  id INT PRIMARY KEY,
  email VARCHAR(45),
  password VARCHAR(255),
  name VARCHAR(45),
  nis VARCHAR(45),          -- Nomor Induk Siswa
  kelas VARCHAR(45),         -- Kelas siswa
  is_admin TINYINT DEFAULT 0 -- 0 = Siswa, 1 = Admin
);
```

## Error Handling

Sistem login sudah dilengkapi dengan error handling untuk:
- Email tidak ditemukan
- Password salah
- Email tidak valid
- Password terlalu pendek
- CSRF token mismatch

## Integrasi Selanjutnya

Untuk melengkapi sistem, Anda dapat menambahkan:
1. **Pengaduan Management** - Create, Read, Update, Delete pengaduan
2. **Kategori Management** - Kelola kategori pengaduan
3. **Feedback System** - Admin dapat memberikan feedback
4. **Image Upload** - Upload foto pengaduan
5. **Status Tracking** - Pantau status pengaduan (Menunggu, Proses, Selesai)

## Tips Pengembangan

### Menambah User Baru
```php
User::create([
    'name' => 'Nama User',
    'email' => 'email@example.com',
    'password' => Hash::make('password'),
    'nis' => '1234567',
    'kelas' => 'XI RPL 1',
    'is_admin' => 0 // atau 1 untuk admin
]);
```

### Mengecek User yang Login
```php
Auth::user()  // Get user instance
Auth::check()  // Boolean
auth()->check() // Alternative syntax
```

### Redirect dengan Message
```php
return redirect('/')->with('success', 'Pesan berhasil!');
return back()->withErrors(['email' => 'Email tidak ditemukan']);
```

## Troubleshooting

### Halaman Blank atau 500 Error
1. Cek error log: `storage/logs/laravel.log`
2. Pastikan migration sudah dijalankan: `php artisan migrate`
3. Clear cache: `php artisan config:clear && php artisan cache:clear`

### Session Tidak Terbaca
1. Pastikan `SESSION_DRIVER=database` di `.env`
2. Jalankan: `php artisan migrate`
3. Restart development server

### Database Connection Error
1. Cek konfigurasi `.env`
2. Pastikan MySQL service berjalan
3. Pastikan database `ukk-bhima` sudah dibuat

## Lisensi
© 2026 Sistem Pengaduan
