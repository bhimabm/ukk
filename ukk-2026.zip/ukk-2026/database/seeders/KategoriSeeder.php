<?php

namespace Database\Seeders;

use App\Models\Kategori;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class KategoriSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $kategoris = [
            'Kerusakan Fasilitas',
            'Bullying',
            'Pelecehan',
            'Pencurian',
            'Vandalism/Pengrusakan',
            'Pelanggaran Tata Tertib',
            'Masalah Kebersihan',
            'Masalah Keamanan',
            'Keluhan Pendidikan',
            'Lainnya',
        ];

        foreach ($kategoris as $nama) {
            Kategori::firstOrCreate(['nama' => $nama]);
        }
    }
}
