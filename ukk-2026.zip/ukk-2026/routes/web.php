<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\PengaduanController;
use App\Http\Controllers\KategoriController;

// Routes untuk Login (Dapat diakses tanpa login)
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
});

// Routes yang memerlukan login
Route::middleware('auth')->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');

    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    // Routes untuk Pengaduan
    Route::resource('pengaduan', PengaduanController::class);
    Route::post('pengaduan/{id}/status', [PengaduanController::class, 'updateStatus'])->name('pengaduan.updateStatus');
    Route::post('pengaduan/{id}/feedback', [PengaduanController::class, 'addFeedback'])->name('pengaduan.addFeedback');

    // Routes untuk Kategori (Admin only)
    Route::resource('kategori', KategoriController::class);
});

// Home route
Route::get('/', [HomeController::class, 'index']);
