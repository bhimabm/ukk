<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pengaduan - Sistem Pengaduan</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
        }

        .navbar {
            background: linear-gradient(135deg, #0284c7 0%, #06b6d4 100%);
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .navbar h1 {
            font-size: 20px;
        }

        .navbar-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .user-info {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
        }

        .user-info .name {
            font-weight: 600;
            font-size: 14px;
        }

        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: #0284c7;
            color: white;
        }

        .btn-primary:hover {
            background: #0167a4;
        }

        .btn-logout {
            padding: 8px 16px;
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .btn-logout:hover {
            background-color: rgba(255, 255, 255, 0.3);
            border-color: rgba(255, 255, 255, 0.5);
        }

        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .page-header h2 {
            color: #333;
            font-size: 28px;
        }

        .alert {
            padding: 15px 20px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .filter-section {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .filter-group {
            display: flex;
            gap: 15px;
            align-items: flex-end;
            flex-wrap: wrap;
        }

        .filter-group label {
            font-weight: 600;
            color: #333;
            font-size: 14px;
        }

        .filter-group select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            min-width: 150px;
        }

        .table-container {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background-color: #0284c7;
            color: white;
        }

        th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #eee;
            font-size: 14px;
        }

        tbody tr:hover {
            background-color: #f9f9f9;
        }

        .status-badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            color: white;
        }

        .status-menunggu {
            background-color: #ffc107;
        }

        .status-proses {
            background-color: #17a2b8;
        }

        .status-selesai {
            background-color: #28a745;
        }

        .action-buttons {
            display: flex;
            gap: 10px;
        }

        .btn-small {
            padding: 6px 12px;
            font-size: 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
        }

        .btn-view {
            background-color: #0284c7;
            color: white;
        }

        .btn-view:hover {
            background-color: #0167a4;
        }

        .btn-edit {
            background-color: #28a745;
            color: white;
        }

        .btn-edit:hover {
            background-color: #218838;
        }

        .btn-delete {
            background-color: #dc3545;
            color: white;
        }

        .btn-delete:hover {
            background-color: #c82333;
        }

        .empty-state {
            text-align: center;
            padding: 40px;
            color: #999;
        }

        .pagination {
            display: flex;
            justify-content: center;
            gap: 5px;
            margin-top: 20px;
            padding: 20px;
        }

        .pagination a,
        .pagination span {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-decoration: none;
            color: #0284c7;
            font-size: 14px;
        }

        .pagination a:hover {
            background-color: #0284c7;
            color: white;
        }

        .pagination .active {
            background-color: #0284c7;
            color: white;
            border-color: #0284c7;
        }

        .breadcrumb {
            margin-bottom: 20px;
            font-size: 14px;
        }

        .breadcrumb a {
            color: #0284c7;
            text-decoration: none;
        }

        .breadcrumb a:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }

            .filter-group {
                flex-direction: column;
                align-items: stretch;
            }

            .filter-group select {
                min-width: unset;
            }

            table {
                font-size: 12px;
            }

            th, td {
                padding: 10px;
            }

            .action-buttons {
                flex-direction: column;
            }

            .btn-small {
                width: 100%;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>Dashboard Sistem Pengaduan</h1>
        <div class="navbar-right">
            <div class="user-info">
                <span class="name"><?php echo e(Auth::user()->name); ?></span>
            </div>
            <form method="POST" action="<?php echo e(route('logout')); ?>" style="margin: 0;">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn-logout">Logout</button>
            </form>
        </div>
    </div>

    <div class="container">
        <div class="breadcrumb">
            <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a> / Pengaduan
        </div>

        <div class="page-header">
            <h2>Kelola Pengaduan</h2>
            <a href="<?php echo e(route('pengaduan.create')); ?>" class="btn btn-primary">+ Buat Pengaduan Baru</a>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <!-- Filter Section -->
        <div class="filter-section">
            <form method="GET" action="<?php echo e(route('pengaduan.index')); ?>">
                <div class="filter-group">
                    <label for="status">Filter Status:</label>
                    <select name="status" id="status" onchange="this.form.submit()">
                        <option value="">Semua Status</option>
                        <option value="Menunggu" <?php echo e(request('status') === 'Menunggu' ? 'selected' : ''); ?>>Menunggu</option>
                        <option value="Proses" <?php echo e(request('status') === 'Proses' ? 'selected' : ''); ?>>Proses</option>
                        <option value="Selesai" <?php echo e(request('status') === 'Selesai' ? 'selected' : ''); ?>>Selesai</option>
                    </select>
                </div>
            </form>
        </div>

        <!-- Table Section -->
        <div class="table-container">
            <?php if($pengaduan->count() > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Kategori</th>
                            <th>Lokasi</th>
                            <th>Keterangan</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pengaduan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(($pengaduan->currentPage() - 1) * $pengaduan->perPage() + $loop->iteration); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($item->tanggal)->format('d/m/Y H:i')); ?></td>
                                <td><?php echo e($item->kategori->nama ?? '-'); ?></td>
                                <td><?php echo e($item->lokasi); ?></td>
                                <td><?php echo e(Str::limit($item->keterangan, 30)); ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo e(strtolower(str_replace(' ', '', $item->status))); ?>">
                                        <?php echo e($item->status); ?>

                                    </span>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <a href="<?php echo e(route('pengaduan.show', $item->id)); ?>" class="btn-small btn-view">Lihat</a>
                                        <?php if(!Auth::user()->is_admin && $item->status === 'Menunggu'): ?>
                                            <a href="<?php echo e(route('pengaduan.edit', $item->id)); ?>" class="btn-small btn-edit">Edit</a>
                                        <?php endif; ?>
                                        <?php if(!Auth::user()->is_admin && $item->status === 'Menunggu'): ?>
                                            <form method="POST" action="<?php echo e(route('pengaduan.destroy', $item->id)); ?>" style="display: inline;" onsubmit="return confirm('Apakah Anda yakin ingin menghapus?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn-small btn-delete">Hapus</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <!-- Pagination -->
                <div class="pagination">
                    <?php if($pengaduan->onFirstPage()): ?>
                        <span>« Sebelumnya</span>
                    <?php else: ?>
                        <a href="<?php echo e($pengaduan->previousPageUrl()); ?>">« Sebelumnya</a>
                    <?php endif; ?>

                    <?php $__currentLoopData = $pengaduan->getUrlRange(1, $pengaduan->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $pengaduan->currentPage()): ?>
                            <span class="active"><?php echo e($page); ?></span>
                        <?php else: ?>
                            <a href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php if($pengaduan->hasMorePages()): ?>
                        <a href="<?php echo e($pengaduan->nextPageUrl()); ?>">Selanjutnya »</a>
                    <?php else: ?>
                        <span>Selanjutnya »</span>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <p>Belum ada pengaduan</p>
                    <p style="margin-top: 10px;">
                        <a href="<?php echo e(route('pengaduan.create')); ?>" style="color: #0284c7; text-decoration: none;">Buat pengaduan baru</a>
                    </p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\ukk-2026\resources\views/pengaduan/index.blade.php ENDPATH**/ ?>