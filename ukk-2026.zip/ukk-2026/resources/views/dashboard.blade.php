<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistem Pengaduan</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
        }

        .navbar {
            background: linear-gradient(135deg, #0284c7 0%, #06b6d4 100%);
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .navbar h1 {
            font-size: 20px;
        }

        .navbar-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .user-info {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
        }

        .user-info .name {
            font-weight: 600;
            font-size: 14px;
        }

        .user-info .role {
            font-size: 12px;
            opacity: 0.9;
        }

        .btn-logout {
            padding: 8px 16px;
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }

        .btn-logout:hover {
            background-color: rgba(255, 255, 255, 0.3);
            border-color: rgba(255, 255, 255, 0.5);
        }

        .container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .welcome-card {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }

        .welcome-card h2 {
            color: #333;
            margin-bottom: 10px;
        }

        .welcome-card p {
            color: #666;
            line-height: 1.6;
        }

        .user-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .detail-card {
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 5px;
            border-left: 4px solid #0284c7;
        }

        .detail-card label {
            display: block;
            color: #999;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            margin-bottom: 5px;
        }

        .detail-card .value {
            color: #333;
            font-size: 16px;
            font-weight: 500;
        }

        .action-buttons {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .btn {
            padding: 12px 20px;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: linear-gradient(135deg, #0284c7 0%, #06b6d4 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(2, 132, 199, 0.4);
        }

        .btn-secondary {
            background-color: #e9ecef;
            color: #495057;
        }

        .btn-secondary:hover {
            background-color: #dee2e6;
        }

        .alert {
            padding: 15px 20px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        @media (max-width: 768px) {
            .navbar {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }

            .navbar-right {
                flex-direction: column;
                width: 100%;
            }

            .user-info {
                align-items: center;
            }

            .btn-logout {
                width: 100%;
                text-align: center;
            }

            .action-buttons {
                flex-direction: column;
            }

            .btn {
                width: 100%;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>Dashboard Sistem Pengaduan</h1>
        <div class="navbar-right">
            <div class="user-info">
                <span class="name">{{ Auth::user()->name }}</span>
                <span class="role">
                    @if(Auth::user()->is_admin)
                        Admin
                    @else
                        Siswa
                    @endif
                </span>
            </div>
            <form method="POST" action="{{ route('logout') }}" style="margin: 0;">
                @csrf
                <button type="submit" class="btn-logout">Logout</button>
            </form>
        </div>
    </div>

    <div class="container">
        @if(session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        <div class="welcome-card">
            <h2>Selamat Datang, {{ Auth::user()->name }}!</h2>
            <p>Anda telah berhasil login ke Sistem Pengaduan. Kelola pengaduan Anda melalui dashboard ini.</p>

            <div class="user-details">
                <div class="detail-card">
                    <label>Email</label>
                    <div class="value">{{ Auth::user()->email }}</div>
                </div>

                @if(Auth::user()->nis)
                    <div class="detail-card">
                        <label>NIS</label>
                        <div class="value">{{ Auth::user()->nis }}</div>
                    </div>
                @endif

                @if(Auth::user()->kelas)
                    <div class="detail-card">
                        <label>Kelas</label>
                        <div class="value">{{ Auth::user()->kelas }}</div>
                    </div>
                @endif

                <div class="detail-card">
                    <label>Tipe Akun</label>
                    <div class="value">
                        @if(Auth::user()->is_admin)
                            <span style="color: #0284c7; font-weight: 600;">Admin</span>
                        @else
                            <span style="color: #06b6d4; font-weight: 600;">Siswa</span>
                        @endif
                    </div>
                </div>
            </div>

            <div class="action-buttons">
                @if(Auth::user()->is_admin)
                    <a href="{{ route('pengaduan.index') }}" class="btn btn-primary">Kelola Pengaduan</a>
                    <a href="{{ route('kategori.index') }}" class="btn btn-secondary">Kelola Kategori</a>
                @else
                    <a href="{{ route('pengaduan.create') }}" class="btn btn-primary">Buat Pengaduan Baru</a>
                    <a href="{{ route('pengaduan.index') }}" class="btn btn-secondary">Lihat Pengaduan Saya</a>
                @endif
            </div>
        </div>
    </div>
</body>
</html>
