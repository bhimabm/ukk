<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pengaduan - Sistem Pengaduan</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
        }

        .navbar {
            background: linear-gradient(135deg, #0284c7 0%, #06b6d4 100%);
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .navbar h1 {
            font-size: 20px;
        }

        .navbar-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .btn-logout {
            padding: 8px 16px;
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .btn-logout:hover {
            background-color: rgba(255, 255, 255, 0.3);
        }

        .container {
            max-width: 800px;
            margin: 30px auto;
            padding: 0 20px;
        }

        .breadcrumb {
            margin-bottom: 20px;
            font-size: 14px;
        }

        .breadcrumb a {
            color: #0284c7;
            text-decoration: none;
        }

        .breadcrumb a:hover {
            text-decoration: underline;
        }

        .page-header h2 {
            color: #333;
            font-size: 28px;
            margin-bottom: 30px;
        }

        .form-container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            font-family: inherit;
            transition: all 0.3s ease;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #0284c7;
            box-shadow: 0 0 0 3px rgba(2, 132, 199, 0.1);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 150px;
        }

        .form-group.error input,
        .form-group.error select,
        .form-group.error textarea {
            border-color: #dc3545;
        }

        .error-message {
            color: #dc3545;
            font-size: 12px;
            margin-top: 5px;
            display: none;
        }

        .form-group.error .error-message {
            display: block;
        }

        .file-input-wrapper {
            position: relative;
            overflow: hidden;
            display: inline-block;
            width: 100%;
        }

        .file-input-wrapper input[type=file] {
            position: absolute;
            left: -9999px;
        }

        .file-input-label {
            display: block;
            padding: 12px;
            background-color: #f9f9f9;
            border: 2px dashed #ddd;
            border-radius: 5px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            color: #666;
            font-size: 14px;
        }

        .file-input-label:hover {
            border-color: #0284c7;
            background-color: #f0f8ff;
        }

        .file-name {
            margin-top: 10px;
            color: #0284c7;
            font-size: 12px;
            display: none;
        }

        .current-photo {
            margin-top: 10px;
        }

        .current-photo img {
            max-width: 200px;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .remove-photo {
            display: inline-block;
            padding: 6px 12px;
            background-color: #dc3545;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            text-decoration: none;
        }

        .remove-photo:hover {
            background-color: #c82333;
        }

        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 5px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: linear-gradient(135deg, #0284c7 0%, #06b6d4 100%);
            color: white;
            flex: 1;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(2, 132, 199, 0.4);
        }

        .btn-cancel {
            background-color: #e9ecef;
            color: #495057;
            flex: 1;
        }

        .btn-cancel:hover {
            background-color: #dee2e6;
        }

        .alert {
            padding: 15px 20px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .help-text {
            font-size: 12px;
            color: #999;
            margin-top: 5px;
        }

        .info-box {
            background-color: #e7f3ff;
            border: 1px solid #b3d9ff;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 14px;
            color: #0066cc;
        }

        @media (max-width: 768px) {
            .form-container {
                padding: 20px;
            }

            .form-actions {
                flex-direction: column;
            }

            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>Sistem Pengaduan</h1>
        <div class="navbar-right">
            <form method="POST" action="{{ route('logout') }}" style="margin: 0;">
                @csrf
                <button type="submit" class="btn-logout">Logout</button>
            </form>
        </div>
    </div>

    <div class="container">
        <div class="breadcrumb">
            <a href="{{ route('dashboard') }}">Dashboard</a> / <a href="{{ route('pengaduan.index') }}">Pengaduan</a> / Edit
        </div>

        <div class="page-header">
            <h2>Edit Pengaduan #{{ $pengaduan->id }}</h2>
        </div>

        <div class="info-box">
            ℹ️ Anda hanya dapat mengedit pengaduan yang berstatus "Menunggu". Pengaduan yang sedang diproses tidak dapat diedit.
        </div>

        @if ($errors->any())
            <div class="alert alert-error">
                <strong>Terjadi kesalahan:</strong>
                <ul style="margin-top: 10px; margin-left: 20px;">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <div class="form-container">
            <form method="POST" action="{{ route('pengaduan.update', $pengaduan->id) }}" enctype="multipart/form-data">
                @csrf
                @method('PUT')

                <div class="form-group @error('kategori_id') error @enderror">
                    <label for="kategori_id">Kategori Pengaduan *</label>
                    <select name="kategori_id" id="kategori_id" required>
                        <option value="">-- Pilih Kategori --</option>
                        @foreach($kategoris as $kategori)
                            <option value="{{ $kategori->id }}" {{ $pengaduan->kategori_id == $kategori->id ? 'selected' : '' }}>
                                {{ $kategori->nama }}
                            </option>
                        @endforeach
                    </select>
                    @error('kategori_id')
                        <span class="error-message">{{ $message }}</span>
                    @enderror
                </div>

                <div class="form-group @error('lokasi') error @enderror">
                    <label for="lokasi">Lokasi Kejadian *</label>
                    <input 
                        type="text" 
                        name="lokasi" 
                        id="lokasi"
                        placeholder="Contoh: Ruang kelas XI RPL 1"
                        value="{{ old('lokasi', $pengaduan->lokasi) }}"
                        maxlength="45"
                        required
                    >
                    <span class="help-text">Maksimal 45 karakter</span>
                    @error('lokasi')
                        <span class="error-message">{{ $message }}</span>
                    @enderror
                </div>

                <div class="form-group @error('keterangan') error @enderror">
                    <label for="keterangan">Keterangan/Deskripsi *</label>
                    <textarea 
                        name="keterangan" 
                        id="keterangan"
                        placeholder="Jelaskan dengan detail tentang pengaduan Anda..."
                        required
                    >{{ old('keterangan', $pengaduan->keterangan) }}</textarea>
                    @error('keterangan')
                        <span class="error-message">{{ $message }}</span>
                    @enderror
                </div>

                <div class="form-group @error('foto') error @enderror">
                    <label for="foto">Foto/Bukti (Opsional)</label>
                    
                    @if($pengaduan->foto)
                        <div class="current-photo">
                            <p style="font-size: 12px; color: #666; margin-bottom: 10px;">Foto saat ini:</p>
                            <img src="{{ asset('storage/' . $pengaduan->foto) }}" alt="Foto pengaduan">
                        </div>
                    @endif

                    <div class="file-input-wrapper">
                        <input 
                            type="file" 
                            name="foto" 
                            id="foto"
                            accept="image/jpeg,image/png,image/jpg,image/gif"
                        >
                        <label for="foto" class="file-input-label">
                            📷 Klik untuk memilih atau drag & drop foto (untuk update)
                        </label>
                        <div class="file-name" id="fileName"></div>
                    </div>
                    <span class="help-text">Format: JPEG, PNG, JPG, GIF | Maksimal ukuran: 2MB</span>
                    @error('foto')
                        <span class="error-message">{{ $message }}</span>
                    @enderror
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    <a href="{{ route('pengaduan.show', $pengaduan->id) }}" class="btn btn-cancel">Batal</a>
                </div>
            </form>
        </div>
    </div>

    <script>
        document.getElementById('foto').addEventListener('change', function(e) {
            const fileName = document.getElementById('fileName');
            if (this.files && this.files[0]) {
                fileName.textContent = '✓ ' + this.files[0].name;
                fileName.style.display = 'block';
            } else {
                fileName.style.display = 'none';
            }
        });
    </script>
</body>
</html>
