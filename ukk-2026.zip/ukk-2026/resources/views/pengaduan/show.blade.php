<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Pengaduan - Sistem Pengaduan</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
        }

        .navbar {
            background: linear-gradient(135deg, #0284c7 0%, #06b6d4 100%);
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .navbar h1 {
            font-size: 20px;
        }

        .navbar-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .btn-logout {
            padding: 8px 16px;
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .btn-logout:hover {
            background-color: rgba(255, 255, 255, 0.3);
        }

        .container {
            max-width: 900px;
            margin: 30px auto;
            padding: 0 20px;
        }

        .breadcrumb {
            margin-bottom: 20px;
            font-size: 14px;
        }

        .breadcrumb a {
            color: #0284c7;
            text-decoration: none;
        }

        .breadcrumb a:hover {
            text-decoration: underline;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 30px;
        }

        .page-header h2 {
            color: #333;
            font-size: 28px;
        }

        .alert {
            padding: 15px 20px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .card {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }

        .card-header h3 {
            color: #333;
            font-size: 18px;
        }

        .status-badge {
            display: inline-block;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            color: white;
        }

        .status-menunggu {
            background-color: #ffc107;
        }

        .status-proses {
            background-color: #17a2b8;
        }

        .status-selesai {
            background-color: #28a745;
        }

        .detail-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .detail-item {
            padding: 15px;
            background-color: #f9f9f9;
            border-radius: 5px;
            border-left: 4px solid #0284c7;
        }

        .detail-item label {
            display: block;
            color: #999;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            margin-bottom: 8px;
        }

        .detail-item .value {
            color: #333;
            font-size: 15px;
            font-weight: 500;
        }

        .detail-full {
            margin-bottom: 20px;
        }

        .detail-full label {
            display: block;
            color: #999;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            margin-bottom: 10px;
        }

        .detail-full .value {
            color: #333;
            font-size: 14px;
            line-height: 1.6;
            padding: 15px;
            background-color: #f9f9f9;
            border-radius: 5px;
            border-left: 4px solid #0284c7;
        }

        .photo-container {
            margin-bottom: 20px;
        }

        .photo-container img {
            max-width: 100%;
            max-height: 400px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .action-buttons {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: linear-gradient(135deg, #0284c7 0%, #06b6d4 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(2, 132, 199, 0.4);
        }

        .btn-success {
            background-color: #28a745;
            color: white;
        }

        .btn-success:hover {
            background-color: #218838;
        }

        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
        }

        .btn-danger {
            background-color: #dc3545;
            color: white;
        }

        .btn-danger:hover {
            background-color: #c82333;
        }

        .feedback-section {
            margin-top: 30px;
        }

        .feedback-section h3 {
            color: #333;
            font-size: 18px;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f0f0f0;
        }

        .feedback-item {
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 15px;
            border-left: 4px solid #28a745;
        }

        .feedback-item .feedback-date {
            font-size: 12px;
            color: #999;
            margin-bottom: 8px;
        }

        .feedback-item .feedback-text {
            color: #333;
            font-size: 14px;
            line-height: 1.6;
        }

        .feedback-form {
            background-color: #f0f8ff;
            padding: 20px;
            border-radius: 5px;
            margin-top: 20px;
        }

        .feedback-form h4 {
            color: #333;
            font-size: 14px;
            margin-bottom: 15px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            font-family: inherit;
            resize: vertical;
            min-height: 100px;
        }

        .form-group textarea:focus {
            outline: none;
            border-color: #0284c7;
            box-shadow: 0 0 0 3px rgba(2, 132, 199, 0.1);
        }

        .status-change-form {
            display: flex;
            gap: 10px;
            align-items: flex-end;
            margin-bottom: 20px;
        }

        .status-change-form select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }

        .status-change-form button {
            padding: 8px 16px;
            background: #0284c7;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
        }

        .status-change-form button:hover {
            background: #0167a4;
        }

        .no-feedback {
            text-align: center;
            padding: 30px;
            color: #999;
        }

        @media (max-width: 768px) {
            .page-header {
                flex-direction: column;
                gap: 15px;
            }

            .action-buttons {
                flex-direction: column;
            }

            .btn {
                width: 100%;
                text-align: center;
            }

            .detail-grid {
                grid-template-columns: 1fr;
            }

            .status-change-form {
                flex-direction: column;
            }

            .status-change-form select {
                width: 100%;
            }

            .status-change-form button {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>Sistem Pengaduan</h1>
        <div class="navbar-right">
            <form method="POST" action="{{ route('logout') }}" style="margin: 0;">
                @csrf
                <button type="submit" class="btn-logout">Logout</button>
            </form>
        </div>
    </div>

    <div class="container">
        <div class="breadcrumb">
            <a href="{{ route('dashboard') }}">Dashboard</a> / <a href="{{ route('pengaduan.index') }}">Pengaduan</a> / Detail
        </div>

        @if(session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        @if(session('error'))
            <div class="alert alert-error">
                {{ session('error') }}
            </div>
        @endif

        <div class="page-header">
            <div>
                <h2>Pengaduan #{{ $pengaduan->id }}</h2>
            </div>
            <span class="status-badge status-{{ strtolower(str_replace(' ', '', $pengaduan->status)) }}">
                {{ $pengaduan->status }}
            </span>
        </div>

        <!-- Detail Pengaduan -->
        <div class="card">
            <div class="card-header">
                <h3>Informasi Pengaduan</h3>
            </div>

            <div class="detail-grid">
                <div class="detail-item">
                    <label>Tanggal</label>
                    <div class="value">{{ \Carbon\Carbon::parse($pengaduan->tanggal)->format('d/m/Y H:i') }}</div>
                </div>
                <div class="detail-item">
                    <label>Kategori</label>
                    <div class="value">{{ $pengaduan->kategori->nama ?? '-' }}</div>
                </div>
                <div class="detail-item">
                    <label>Lokasi</label>
                    <div class="value">{{ $pengaduan->lokasi }}</div>
                </div>
                <div class="detail-item">
                    <label>Nama Pelapor</label>
                    <div class="value">{{ $pengaduan->user->name }}</div>
                </div>
            </div>

            <div class="detail-full">
                <label>Keterangan</label>
                <div class="value">{{ $pengaduan->keterangan }}</div>
            </div>

            @if($pengaduan->foto)
                <div class="photo-container">
                    <label>Foto/Bukti</label>
                    <img src="{{ asset('storage/' . $pengaduan->foto) }}" alt="Foto pengaduan">
                </div>
            @endif

            <!-- Action Buttons -->
            <div class="action-buttons">
                @if(!Auth::user()->is_admin && $pengaduan->status === 'Menunggu' && $pengaduan->user_id === Auth::id())
                    <a href="{{ route('pengaduan.edit', $pengaduan->id) }}" class="btn btn-primary">Edit</a>
                    <form method="POST" action="{{ route('pengaduan.destroy', $pengaduan->id) }}" style="display: inline;" onsubmit="return confirm('Apakah Anda yakin ingin menghapus?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger">Hapus</button>
                    </form>
                @endif
                <a href="{{ route('pengaduan.index') }}" class="btn btn-secondary">Kembali</a>
            </div>
        </div>

        <!-- Status Change (Admin Only) -->
        @if(Auth::user()->is_admin)
            <div class="card">
                <div class="card-header">
                    <h3>Ubah Status</h3>
                </div>
                <form method="POST" action="{{ route('pengaduan.updateStatus', $pengaduan->id) }}" class="status-change-form">
                    @csrf
                    <select name="status" required>
                        <option value="Menunggu" {{ $pengaduan->status === 'Menunggu' ? 'selected' : '' }}>Menunggu</option>
                        <option value="Proses" {{ $pengaduan->status === 'Proses' ? 'selected' : '' }}>Proses</option>
                        <option value="Selesai" {{ $pengaduan->status === 'Selesai' ? 'selected' : '' }}>Selesai</option>
                    </select>
                    <button type="submit">Simpan Status</button>
                </form>
            </div>
        @endif

        <!-- Feedback Section -->
        <div class="card feedback-section">
            <h3>Feedback</h3>

            @if($pengaduan->feedbacks && $pengaduan->feedbacks->count() > 0)
                @foreach($pengaduan->feedbacks as $feedback)
                    <div class="feedback-item">
                        <div class="feedback-date">📝 Admin - {{ \Carbon\Carbon::parse($feedback->tanggal)->format('d/m/Y H:i') }}</div>
                        <div class="feedback-text">{{ $feedback->isi }}</div>
                    </div>
                @endforeach
            @else
                <div class="no-feedback">
                    Belum ada feedback dari admin
                </div>
            @endif

            <!-- Add Feedback (Admin Only) -->
            @if(Auth::user()->is_admin)
                <div class="feedback-form">
                    <h4>Tambah Feedback</h4>
                    <form method="POST" action="{{ route('pengaduan.addFeedback', $pengaduan->id) }}">
                        @csrf
                        <div class="form-group">
                            <textarea name="isi" placeholder="Masukkan feedback untuk pengaduan ini..." required></textarea>
                        </div>
                        <button type="submit" class="btn btn-success">Kirim Feedback</button>
                    </form>
                </div>
            @endif
        </div>
    </div>
</body>
</html>
