<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Pengaduan - Beranda</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0284c7 0%, #06b6d4 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 600px;
            padding: 60px 40px;
            text-align: center;
        }

        .logo {
            font-size: 48px;
            margin-bottom: 20px;
        }

        h1 {
            color: #333;
            font-size: 32px;
            margin-bottom: 10px;
        }

        .subtitle {
            color: #666;
            font-size: 16px;
            margin-bottom: 30px;
            line-height: 1.6;
        }

        .feature-list {
            text-align: left;
            margin: 30px 0;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 8px;
        }

        .feature-list h3 {
            color: #333;
            margin-bottom: 15px;
            font-size: 18px;
        }

        .feature-item {
            display: flex;
            align-items: center;
            margin-bottom: 12px;
            color: #666;
            font-size: 15px;
        }

        .feature-item:before {
            content: "✓";
            color: #667eea;
            font-weight: bold;
            margin-right: 10px;
            font-size: 18px;
        }

        .cta-buttons {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            flex-direction: column;
        }

        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: linear-gradient(135deg, #0284c7 0%, #06b6d4 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(2, 132, 199, 0.4);
        }

        .btn-secondary {
            background-color: #e9ecef;
            color: #495057;
            border: 1px solid #dee2e6;
        }

        .btn-secondary:hover {
            background-color: #dee2e6;
        }

        @media (max-width: 600px) {
            .container {
                padding: 40px 20px;
            }

            h1 {
                font-size: 24px;
            }

            .subtitle {
                font-size: 14px;
            }

            .logo {
                font-size: 36px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">📋</div>

        <h1>Sistem Pengaduan</h1>
        <p class="subtitle">Platform untuk melaporkan dan mengelola pengaduan dengan mudah dan transparan</p>

        <div class="feature-list">
            <h3>Fitur Utama</h3>
            <div class="feature-item">Lapor pengaduan dengan mudah dan cepat</div>
            <div class="feature-item">Pantau status pengaduan secara real-time</div>
            <div class="feature-item">Dapatkan feedback dari admin</div>
            <div class="feature-item">Sistem yang aman dan terpercaya</div>
        </div>

        <div class="cta-buttons">
            <a href="{{ route('login') }}" class="btn btn-primary">Masuk</a>
            <div style="text-align: center; color: #999; font-size: 14px; margin-top: 10px;">
                <p>Belum punya akun? Hubungi administrator</p>
            </div>
        </div>
    </div>
</body>
</html>
