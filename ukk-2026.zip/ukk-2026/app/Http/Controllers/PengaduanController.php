<?php

namespace App\Http\Controllers;

use App\Models\Pengaduan;
use App\Models\Kategori;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class PengaduanController extends Controller
{
    // Tampilkan daftar pengaduan
    public function index(Request $request)
    {
        $query = Pengaduan::with(['user', 'kategori']);

        // Filter berdasarkan user jika bukan admin
        if (!Auth::user()->is_admin) {
            $query->where('user_id', Auth::id());
        }

        // Filter berdasarkan status jika ada parameter
        if ($request->has('status') && $request->status) {
            $query->where('status', $request->status);
        }

        $pengaduan = $query->orderBy('tanggal', 'desc')->paginate(10);

        return view('pengaduan.index', compact('pengaduan'));
    }

    // Tampilkan form create
    public function create()
    {
        $kategoris = Kategori::all();
        return view('pengaduan.create', compact('kategoris'));
    }

    // Store pengaduan baru
    public function store(Request $request)
    {
        $validated = $request->validate([
            'kategori_id' => 'required|exists:kategori,id',
            'lokasi' => 'required|string|max:45',
            'keterangan' => 'required|string',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ], [
            'kategori_id.required' => 'Kategori wajib dipilih',
            'kategori_id.exists' => 'Kategori tidak valid',
            'lokasi.required' => 'Lokasi wajib diisi',
            'lokasi.max' => 'Lokasi maksimal 45 karakter',
            'keterangan.required' => 'Keterangan wajib diisi',
            'foto.image' => 'File harus berupa gambar',
            'foto.mimes' => 'Format gambar harus: jpeg, png, jpg, gif',
            'foto.max' => 'Ukuran gambar maksimal 2MB',
        ]);

        // Handle foto upload
        if ($request->hasFile('foto')) {
            $file = $request->file('foto');
            $filename = 'pengaduan_' . time() . '.' . $file->getClientOriginalExtension();
            $file->storeAs('public/pengaduan', $filename);
            $validated['foto'] = 'pengaduan/' . $filename;
        }

        $validated['user_id'] = Auth::id();
        $validated['tanggal'] = now();
        $validated['status'] = 'Menunggu';

        Pengaduan::create($validated);

        return redirect()->route('pengaduan.index')
                        ->with('success', 'Pengaduan berhasil dibuat!');
    }

    // Tampilkan detail pengaduan
    public function show($id)
    {
        $pengaduan = Pengaduan::with(['user', 'kategori', 'feedbacks'])
                              ->findOrFail($id);

        // Cek autoritas
        if (!Auth::user()->is_admin && $pengaduan->user_id !== Auth::id()) {
            abort(403, 'Anda tidak berhak mengakses data ini');
        }

        return view('pengaduan.show', compact('pengaduan'));
    }

    // Tampilkan form edit
    public function edit($id)
    {
        $pengaduan = Pengaduan::findOrFail($id);

        // Cek autoritas
        if (!Auth::user()->is_admin && $pengaduan->user_id !== Auth::id()) {
            abort(403, 'Anda tidak berhak mengedit data ini');
        }

        // Jika status bukan 'Menunggu', tidak boleh edit (kecuali admin)
        if (!Auth::user()->is_admin && $pengaduan->status !== 'Menunggu') {
            return redirect()->route('pengaduan.show', $id)
                            ->with('error', 'Pengaduan tidak dapat diedit');
        }

        $kategoris = Kategori::all();
        return view('pengaduan.edit', compact('pengaduan', 'kategoris'));
    }

    // Update pengaduan
    public function update(Request $request, $id)
    {
        $pengaduan = Pengaduan::findOrFail($id);

        // Cek autoritas
        if (!Auth::user()->is_admin && $pengaduan->user_id !== Auth::id()) {
            abort(403, 'Anda tidak berhak mengubah data ini');
        }

        // Jika status bukan 'Menunggu', tidak boleh update (kecuali admin)
        if (!Auth::user()->is_admin && $pengaduan->status !== 'Menunggu') {
            return redirect()->route('pengaduan.show', $id)
                            ->with('error', 'Pengaduan tidak dapat diubah');
        }

        $validated = $request->validate([
            'kategori_id' => 'required|exists:kategori,id',
            'lokasi' => 'required|string|max:45',
            'keterangan' => 'required|string',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'status' => Auth::user()->is_admin ? 'sometimes|in:Menunggu,Proses,Selesai' : '',
        ]);

        // Handle foto upload
        if ($request->hasFile('foto')) {
            // Hapus foto lama
            if ($pengaduan->foto) {
                Storage::delete('public/' . $pengaduan->foto);
            }

            $file = $request->file('foto');
            $filename = 'pengaduan_' . time() . '.' . $file->getClientOriginalExtension();
            $file->storeAs('public/pengaduan', $filename);
            $validated['foto'] = 'pengaduan/' . $filename;
        }

        $pengaduan->update($validated);

        return redirect()->route('pengaduan.show', $id)
                        ->with('success', 'Pengaduan berhasil diperbarui!');
    }

    // Hapus pengaduan
    public function destroy($id)
    {
        $pengaduan = Pengaduan::findOrFail($id);

        // Cek autoritas
        if (!Auth::user()->is_admin && $pengaduan->user_id !== Auth::id()) {
            abort(403, 'Anda tidak berhak menghapus data ini');
        }

        // Hanya bisa hapus jika status 'Menunggu'
        if ($pengaduan->status !== 'Menunggu') {
            return redirect()->route('pengaduan.index')
                            ->with('error', 'Hanya pengaduan dengan status Menunggu yang dapat dihapus');
        }

        // Hapus foto
        if ($pengaduan->foto) {
            Storage::delete('public/' . $pengaduan->foto);
        }

        $pengaduan->delete();

        return redirect()->route('pengaduan.index')
                        ->with('success', 'Pengaduan berhasil dihapus!');
    }

    // Update status (hanya admin)
    public function updateStatus(Request $request, $id)
    {
        if (!Auth::user()->is_admin) {
            abort(403, 'Hanya admin yang dapat mengubah status');
        }

        $pengaduan = Pengaduan::findOrFail($id);

        $validated = $request->validate([
            'status' => 'required|in:Menunggu,Proses,Selesai',
        ]);

        $pengaduan->update($validated);

        return redirect()->route('pengaduan.show', $id)
                        ->with('success', 'Status berhasil diperbarui!');
    }

    // Tambah feedback (hanya admin)
    public function addFeedback(Request $request, $id)
    {
        if (!Auth::user()->is_admin) {
            abort(403, 'Hanya admin yang dapat menambah feedback');
        }

        $pengaduan = Pengaduan::findOrFail($id);

        $validated = $request->validate([
            'isi' => 'required|string',
        ], [
            'isi.required' => 'Feedback wajib diisi',
        ]);

        $pengaduan->feedbacks()->create([
            'isi' => $validated['isi'],
            'tanggal' => now(),
        ]);

        return redirect()->route('pengaduan.show', $id)
                        ->with('success', 'Feedback berhasil ditambahkan!');
    }
}
