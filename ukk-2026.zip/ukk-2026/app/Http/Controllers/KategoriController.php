<?php

namespace App\Http\Controllers;

use App\Models\Kategori;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class KategoriController extends Controller
{
    // Tampilkan daftar kategori
    public function index()
    {
        // Jika bukan admin, redirect ke dashboard
        if (!Auth::user()->is_admin) {
            return redirect('/dashboard')->with('error', 'Anda tidak memiliki akses ke halaman ini');
        }

        $kategoris = Kategori::paginate(10);
        return view('kategori.index', compact('kategoris'));
    }

    // Tampilkan form create
    public function create()
    {
        // Jika bukan admin, redirect ke dashboard
        if (!Auth::user()->is_admin) {
            return redirect('/dashboard')->with('error', 'Anda tidak memiliki akses ke halaman ini');
        }

        return view('kategori.create');
    }

    // Store kategori baru
    public function store(Request $request)
    {
        // Jika bukan admin, redirect ke dashboard
        if (!Auth::user()->is_admin) {
            return redirect('/dashboard')->with('error', 'Anda tidak memiliki akses ke halaman ini');
        }

        $validated = $request->validate([
            'nama' => 'required|string|max:45|unique:kategori,nama',
        ], [
            'nama.required' => 'Nama kategori wajib diisi',
            'nama.max' => 'Nama kategori maksimal 45 karakter',
            'nama.unique' => 'Nama kategori sudah ada',
        ]);

        Kategori::create($validated);

        return redirect()->route('kategori.index')
                        ->with('success', 'Kategori berhasil ditambahkan!');
    }

    // Tampilkan form edit
    public function edit($id)
    {
        // Jika bukan admin, redirect ke dashboard
        if (!Auth::user()->is_admin) {
            return redirect('/dashboard')->with('error', 'Anda tidak memiliki akses ke halaman ini');
        }

        $kategori = Kategori::findOrFail($id);
        return view('kategori.edit', compact('kategori'));
    }

    // Update kategori
    public function update(Request $request, $id)
    {
        // Jika bukan admin, redirect ke dashboard
        if (!Auth::user()->is_admin) {
            return redirect('/dashboard')->with('error', 'Anda tidak memiliki akses ke halaman ini');
        }

        $kategori = Kategori::findOrFail($id);

        $validated = $request->validate([
            'nama' => 'required|string|max:45|unique:kategori,nama,' . $id,
        ], [
            'nama.required' => 'Nama kategori wajib diisi',
            'nama.max' => 'Nama kategori maksimal 45 karakter',
            'nama.unique' => 'Nama kategori sudah ada',
        ]);

        $kategori->update($validated);

        return redirect()->route('kategori.index')
                        ->with('success', 'Kategori berhasil diperbarui!');
    }

    // Hapus kategori
    public function destroy($id)
    {
        // Jika bukan admin, redirect ke dashboard
        if (!Auth::user()->is_admin) {
            return redirect('/dashboard')->with('error', 'Anda tidak memiliki akses ke halaman ini');
        }

        $kategori = Kategori::findOrFail($id);

        // Cek apakah kategori masih digunakan oleh pengaduan
        if ($kategori->pengaduan()->count() > 0) {
            return redirect()->route('kategori.index')
                            ->with('error', 'Kategori tidak dapat dihapus karena masih digunakan oleh pengaduan');
        }

        $kategori->delete();

        return redirect()->route('kategori.index')
                        ->with('success', 'Kategori berhasil dihapus!');
    }
}
