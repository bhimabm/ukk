<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pengaduan extends Model
{
    use HasFactory;

    protected $table = 'pengaduan';

    protected $fillable = [
        'user_id',
        'kategori_id',
        'tanggal',
        'lokasi',
        'keterangan',
        'foto',
        'status',
    ];

    public $timestamps = false;

    // Relationship dengan User
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    // Relationship dengan Kategori
    public function kategori()
    {
        return $this->belongsTo(Kategori::class);
    }

    // Relationship dengan Feedback
    public function feedbacks()
    {
        return $this->hasMany(Feedback::class);
    }

    // Accessor untuk format tanggal
    public function getTanggalFormatAttribute()
    {
        return \Carbon\Carbon::parse($this->tanggal)->format('d/m/Y H:i');
    }

    // Status badge color
    public function getStatusColorAttribute()
    {
        $colors = [
            'Menunggu' => '#ffc107',
            'Proses' => '#17a2b8',
            'Selesai' => '#28a745',
        ];
        return $colors[$this->status] ?? '#6c757d';
    }
}
