

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <!-- Header -->
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-800">Dashboard Admin</h1>
        <p class="text-gray-600">Selamat datang, <?php echo e(Auth::user()->name); ?></p>
    </div>

    <!-- Statistics Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <!-- Total Pengaduan -->
        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-blue-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm">Total Pengaduan</p>
                    <p class="text-3xl font-bold text-blue-500"><?php echo e($totalPengaduan); ?></p>
                </div>
                <div class="text-blue-500 text-3xl">
                    <i class="fas fa-file-alt"></i>
                </div>
            </div>
        </div>

        <!-- Pengaduan Menunggu -->
        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-yellow-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm">Menunggu</p>
                    <p class="text-3xl font-bold text-yellow-500"><?php echo e($pengaduanMenunggu); ?></p>
                </div>
                <div class="text-yellow-500 text-3xl">
                    <i class="fas fa-clock"></i>
                </div>
            </div>
        </div>

        <!-- Pengaduan Proses -->
        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-orange-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm">Proses</p>
                    <p class="text-3xl font-bold text-orange-500"><?php echo e($pengaduanProses); ?></p>
                </div>
                <div class="text-orange-500 text-3xl">
                    <i class="fas fa-spinner"></i>
                </div>
            </div>
        </div>

        <!-- Pengaduan Selesai -->
        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-green-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm">Selesai</p>
                    <p class="text-3xl font-bold text-green-500"><?php echo e($pengaduanSelesai); ?></p>
                </div>
                <div class="text-green-500 text-3xl">
                    <i class="fas fa-check-circle"></i>
                </div>
            </div>
        </div>

        <!-- Total Siswa -->
        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-purple-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm">Total Siswa</p>
                    <p class="text-3xl font-bold text-purple-500"><?php echo e($totalSiswa); ?></p>
                </div>
                <div class="text-purple-500 text-3xl">
                    <i class="fas fa-users"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts Section -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <!-- Status Pie Chart -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-bold text-gray-800 mb-4">Distribusi Status Pengaduan</h2>
            <div class="flex items-center justify-center" style="height: 300px;">
                <canvas id="statusChart"></canvas>
            </div>
        </div>

        <!-- Kategori Bar Chart -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-bold text-gray-800 mb-4">Pengaduan per Kategori</h2>
            <div class="flex items-center justify-center" style="height: 300px;">
                <canvas id="kategoriChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Recent Complaints -->
    <div class="bg-white rounded-lg shadow-md p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Pengaduan Terbaru</h2>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-50 border-b">
                    <tr>
                        <th class="px-4 py-3 text-left">Tanggal</th>
                        <th class="px-4 py-3 text-left">Siswa</th>
                        <th class="px-4 py-3 text-left">Kategori</th>
                        <th class="px-4 py-3 text-left">Status</th>
                        <th class="px-4 py-3 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $pengaduanTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="border-b hover:bg-gray-50">
                        <td class="px-4 py-3"><?php echo e($item->tanggal ? \Carbon\Carbon::parse($item->tanggal)->format('d/m/Y H:i') : '-'); ?></td>
                        <td class="px-4 py-3"><?php echo e(optional($item->user)->name ?? '-'); ?></td>
                        <td class="px-4 py-3"><?php echo e(optional($item->kategori)->nama ?? '-'); ?></td>
                        <td class="px-4 py-3">
                            <span class="px-3 py-1 rounded-full text-xs font-semibold
                                <?php if($item->status == 'Menunggu'): ?> bg-yellow-100 text-yellow-800
                                <?php elseif($item->status == 'Proses'): ?> bg-orange-100 text-orange-800
                                <?php else: ?> bg-green-100 text-green-800
                                <?php endif; ?>">
                                <?php echo e($item->status); ?>

                            </span>
                        </td>
                        <td class="px-4 py-3 text-center">
                            <a href="<?php echo e(route('pengaduan.show', $item)); ?>" class="text-blue-500 hover:text-blue-700">
                                <i class="fas fa-eye"></i> Lihat
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="px-4 py-3 text-center text-gray-600">Belum ada pengaduan</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="mt-4">
            <a href="<?php echo e(route('pengaduan.index')); ?>" class="text-blue-500 hover:text-blue-700 font-semibold">
                Lihat semua pengaduan →
            </a>
        </div>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Status Pie Chart
    const statusCtx = document.getElementById('statusChart').getContext('2d');
    new Chart(statusCtx, {
        type: 'doughnut',
        data: {
            labels: ['Menunggu', 'Proses', 'Selesai'],
            datasets: [{
                data: [<?php echo e($statusData['Menunggu']); ?>, <?php echo e($statusData['Proses']); ?>, <?php echo e($statusData['Selesai']); ?>],
                backgroundColor: ['#FCD34D', '#FB923C', '#10B981'],
                borderColor: ['#F59E0B', '#EA580C', '#059669'],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });

    // Kategori Bar Chart
    const kategoriCtx = document.getElementById('kategoriChart').getContext('2d');
    new Chart(kategoriCtx, {
        type: 'bar',
        data: {
            labels: [
                <?php $__currentLoopData = $pengaduanPerKategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                '<?php echo e($item['nama']); ?>',
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            datasets: [{
                label: 'Jumlah Pengaduan',
                data: [
                    <?php $__currentLoopData = $pengaduanPerKategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($item['count']); ?>,
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],
                backgroundColor: '#3B82F6',
                borderColor: '#1E40AF',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            },
            plugins: {
                legend: {
                    display: true
                }
            }
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\!ukk-pengaduan\resources\views/dashboard/admin.blade.php ENDPATH**/ ?>