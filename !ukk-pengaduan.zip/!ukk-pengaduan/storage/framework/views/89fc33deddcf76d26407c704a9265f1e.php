

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <!-- Header -->
    <div class="mb-8">
        <div class="flex justify-between items-center">
            <div>
                <h1 class="text-3xl font-bold text-gray-800">Daftar Pengaduan</h1>
            </div>
            <?php if(!Auth::user()->isAdmin()): ?>
            <a href="<?php echo e(route('pengaduan.create')); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                <i class="fas fa-plus"></i> Buat Pengaduan Baru
            </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Alert Messages -->
    <?php if(session('success')): ?>
    <div class="mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
    <div class="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded">
        <?php echo e(session('error')); ?>

    </div>
    <?php endif; ?>

    <!-- Pengaduan Table -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-100 border-b">
                    <tr>
                        <th class="px-4 py-3 text-left">Tanggal</th>
                        <?php if(Auth::user()->isAdmin()): ?>
                        <th class="px-4 py-3 text-left">Siswa</th>
                        <?php endif; ?>
                        <th class="px-4 py-3 text-left">Kategori</th>
                        <th class="px-4 py-3 text-left">Lokasi</th>
                        <th class="px-4 py-3 text-left">Keterangan</th>
                        <th class="px-4 py-3 text-left">Status</th>
                        <th class="px-4 py-3 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $pengaduan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="border-b hover:bg-gray-50">
                        <td class="px-4 py-3 whitespace-nowrap"><?php echo e($item->tanggal ? \Carbon\Carbon::parse($item->tanggal)->format('d/m/Y') : '-'); ?></td>
                        <?php if(Auth::user()->isAdmin()): ?>
                        <td class="px-4 py-3"><?php echo e(optional($item->user)->name ?? '-'); ?></td>
                        <?php endif; ?>
                        <td class="px-4 py-3"><?php echo e(optional($item->kategori)->nama ?? '-'); ?></td>
                        <td class="px-4 py-3"><?php echo e($item->lokasi); ?></td>
                        <td class="px-4 py-3"><?php echo e(\Illuminate\Support\Str::limit($item->keterangan, 30)); ?></td>
                        <td class="px-4 py-3">
                            <span class="px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap
                                <?php if($item->status == 'Menunggu'): ?> bg-yellow-100 text-yellow-800
                                <?php elseif($item->status == 'Proses'): ?> bg-orange-100 text-orange-800
                                <?php else: ?> bg-green-100 text-green-800
                                <?php endif; ?>">
                                <?php echo e($item->status); ?>

                            </span>
                        </td>
                        <td class="px-4 py-3 text-center">
                            <a href="<?php echo e(route('pengaduan.show', $item)); ?>" class="text-blue-500 hover:text-blue-700" title="Lihat">
                                <i class="fas fa-eye"></i>
                            </a>
                            <?php if(!Auth::user()->isAdmin() && $item->status == 'Menunggu'): ?>
                            <a href="<?php echo e(route('pengaduan.edit', $item)); ?>" class="text-yellow-500 hover:text-yellow-700 ml-2" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="<?php echo e(route('pengaduan.destroy', $item)); ?>" method="POST" class="inline" onsubmit="return confirm('Yakin ingin menghapus?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-500 hover:text-red-700 ml-2" title="Hapus">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="<?php echo e(Auth::user()->isAdmin() ? 7 : 6); ?>" class="px-4 py-3 text-center text-gray-600">
                            Belum ada pengaduan
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($pengaduan->hasPages()): ?>
        <div class="px-4 py-3 bg-gray-50 border-t">
            <?php echo e($pengaduan->links()); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\!ukk-pengaduan\resources\views/pengaduan/index.blade.php ENDPATH**/ ?>