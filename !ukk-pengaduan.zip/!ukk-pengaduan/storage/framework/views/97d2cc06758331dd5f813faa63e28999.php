<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Sistem Pengaduan Siswa'); ?></title>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        body {
            background-color: #f8f9fa;
        }
    </style>
</head>
<body class="flex flex-col min-h-screen">
    <!-- Navigation -->
    <nav class="bg-blue-600 text-white shadow-lg">
        <div class="container mx-auto px-4">
            <div class="flex justify-between items-center py-4">
                <!-- Brand -->
                <a href="/" class="flex items-center gap-3 hover:text-blue-100 transition">
                    <i class="fas fa-megaphone text-2xl"></i>
                    <div>
                        <h1 class="text-xl font-bold">Sistem Pengaduan Siswa</h1>
                        <p class="text-xs text-blue-100">UKK P3 2026</p>
                    </div>
                </a>

                <!-- Menu -->
                <?php if(auth()->guard()->check()): ?>
                <div class="flex items-center gap-6">
                    <a href="<?php echo e(route('dashboard')); ?>" class="hover:text-blue-100 transition">
                        <i class="fas fa-home"></i> Dashboard
                    </a>
                    
                    <?php if(Auth::user()->isAdmin()): ?>
                    <a href="<?php echo e(route('kategori.index')); ?>" class="hover:text-blue-100 transition">
                        <i class="fas fa-tags"></i> Kategori
                    </a>
                    <?php else: ?>
                    <a href="<?php echo e(route('pengaduan.create')); ?>" class="hover:text-blue-100 transition">
                        <i class="fas fa-plus"></i> Buat Pengaduan
                    </a>
                    <?php endif; ?>

                    <a href="<?php echo e(route('pengaduan.index')); ?>" class="hover:text-blue-100 transition">
                        <i class="fas fa-list"></i> Pengaduan
                    </a>

                    <!-- User Dropdown -->
                    <div class="relative group">
                        <button class="flex items-center gap-2 hover:text-blue-100 transition">
                            <i class="fas fa-user-circle text-2xl"></i>
                            <span class="text-sm"><?php echo e(Auth::user()->name); ?></span>
                            <i class="fas fa-chevron-down text-xs"></i>
                        </button>
                        
                        <div class="absolute right-0 mt-2 w-48 bg-white text-gray-800 rounded-lg shadow-xl hidden group-hover:block z-50">
                            <div class="px-4 py-2 border-b">
                                <p class="text-sm"><strong><?php echo e(Auth::user()->name); ?></strong></p>
                                <p class="text-xs text-gray-500"><?php echo e(Auth::user()->email); ?></p>
                                <?php if(Auth::user()->isAdmin()): ?>
                                <span class="inline-block mt-1 bg-red-100 text-red-700 px-2 py-1 text-xs rounded">Admin</span>
                                <?php else: ?>
                                <p class="text-xs text-gray-500"><?php echo e(Auth::user()->kelas ?? 'N/A'); ?></p>
                                <?php endif; ?>
                            </div>
                            <form action="<?php echo e(route('logout')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="w-full text-left px-4 py-2 hover:bg-gray-100">
                                    <i class="fas fa-sign-out-alt"></i> Logout
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <div class="flex items-center gap-4">
                    <a href="<?php echo e(route('login')); ?>" class="hover:text-blue-100 transition">Login</a>
                    <a href="<?php echo e(route('register')); ?>" class="bg-white text-blue-600 px-4 py-2 rounded hover:bg-blue-50 transition font-semibold">Daftar</a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="flex-grow py-8">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <!-- Footer -->
    <footer class="bg-gray-800 text-white text-center py-6 border-t border-gray-700">
        <div class="container mx-auto px-4">
            <p>&copy; 2026 Sistem Pengaduan Siswa. All rights reserved.</p>
            <p class="text-sm text-gray-400 mt-2">UKK P3 2026 - Sekolah Menengah Kejuruan</p>
        </div>
    </footer>

    <!-- Scripts -->
    <script>
        // Logout confirmation
        document.querySelectorAll('form').forEach(form => {
            if (form.querySelector('button[type="submit"]')?.textContent.includes('Logout')) {
                form.addEventListener('submit', function(e) {
                    if (!confirm('Yakin ingin keluar?')) {
                        e.preventDefault();
                    }
                });
            }
        });
    </script>
</body>
</html>
<?php /**PATH C:\laragon\www\!ukk-pengaduan\resources\views/layouts/app.blade.php ENDPATH**/ ?>