@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4 py-8 max-w-3xl">
    <!-- Header -->
    <div class="mb-6 flex justify-between items-start">
        <div>
            <h1 class="text-3xl font-bold text-gray-800">Detail Pengaduan</h1>
            <p class="text-gray-600">{{ optional($pengaduan->kategori)->nama ?? '-' }}</p>
        </div>
        <a href="{{ route('pengaduan.index') }}" class="text-blue-500 hover:text-blue-700">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
    </div>

    <!-- Alert Messages -->
    @if(session('success'))
    <div class="mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded">
        {{ session('success') }}
    </div>
    @endif

    @if(session('error'))
    <div class="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded">
        {{ session('error') }}
    </div>
    @endif

    <!-- Main Content -->
    <div class="bg-white rounded-lg shadow-md p-6 mb-6">
        <!-- Status Badge -->
        <div class="mb-4 flex justify-between items-center">
            <span class="px-4 py-2 rounded-full text-sm font-semibold
                @if($pengaduan->status == 'Menunggu') bg-yellow-100 text-yellow-800
                @elseif($pengaduan->status == 'Proses') bg-orange-100 text-orange-800
                @else bg-green-100 text-green-800
                @endif">
                Status: {{ $pengaduan->status }}
            </span>
            @if(Auth::user()->isAdmin())
            <form action="{{ route('pengaduan.updateStatus', $pengaduan) }}" method="POST" class="flex gap-2">
                @csrf
                <select name="status" class="px-3 py-1 border border-gray-300 rounded">
                    <option value="Menunggu" {{ $pengaduan->status == 'Menunggu' ? 'selected' : '' }}>Menunggu</option>
                    <option value="Proses" {{ $pengaduan->status == 'Proses' ? 'selected' : '' }}>Proses</option>
                    <option value="Selesai" {{ $pengaduan->status == 'Selesai' ? 'selected' : '' }}>Selesai</option>
                </select>
                <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm">
                    <i class="fas fa-check"></i> Update
                </button>
            </form>
            @endif
        </div>

        <!-- Pengaduan Info -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
                <h3 class="text-sm font-semibold text-gray-600 mb-1">Kategori</h3>
                <p class="text-lg text-gray-800">{{ $pengaduan->kategori->nama }}</p>
            </div>
            <div>
                <h3 class="text-sm font-semibold text-gray-600 mb-1">Tanggal Pengaduan</h3>
                <p class="text-lg text-gray-800">{{ $pengaduan->tanggal ? \Carbon\Carbon::parse($pengaduan->tanggal)->format('d/m/Y H:i') : '-' }}</p>
            </div>
            <div>
                <h3 class="text-sm font-semibold text-gray-600 mb-1">Lokasi</h3>
                <p class="text-lg text-gray-800">{{ $pengaduan->lokasi }}</p>
            </div>
            <div>
                <h3 class="text-sm font-semibold text-gray-600 mb-1">Pengadu</h3>
                <p class="text-lg text-gray-800">{{ optional($pengaduan->user)->name ?? '-' }}</p>
            </div>
        </div>

        <!-- Keterangan -->
        <div class="mb-6">
            <h3 class="text-sm font-semibold text-gray-600 mb-2">Keterangan</h3>
            <p class="text-gray-700 whitespace-pre-wrap">{{ $pengaduan->keterangan }}</p>
        </div>

        <!-- Foto -->
        @if($pengaduan->foto)
        <div class="mb-6">
            <h3 class="text-sm font-semibold text-gray-600 mb-2">Foto Dokumentasi</h3>
            <img src="{{ asset('uploads/pengaduan/' . $pengaduan->foto) }}" alt="Foto pengaduan" class="max-h-96 rounded-lg">
        </div>
        @endif

        <!-- Action Buttons -->
        @if(!Auth::user()->isAdmin() && $pengaduan->status == 'Menunggu')
        <div class="flex gap-2 pt-4 border-t">
            <a href="{{ route('pengaduan.edit', $pengaduan) }}" class="bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-2 px-4 rounded">
                <i class="fas fa-edit"></i> Edit
            </a>
            <form action="{{ route('pengaduan.destroy', $pengaduan) }}" method="POST" class="inline" onsubmit="return confirm('Yakin ingin menghapus?')">
                @csrf
                @method('DELETE')
                <button type="submit" class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                    <i class="fas fa-trash"></i> Hapus
                </button>
            </form>
        </div>
        @endif
    </div>

    <!-- Feedback Section -->
    <div class="bg-white rounded-lg shadow-md p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-6">
            <i class="fas fa-comments"></i> Feedback ({{ optional($pengaduan->feedback)->count() ?? 0 }})
        </h2>

        <!-- Daftar Feedback -->
        @if($pengaduan->feedback->count() > 0)
        <div class="space-y-4 mb-6">
            @foreach($pengaduan->feedback as $fb)
            <div class="bg-gray-50 rounded-lg p-4 border border-gray-200">
            <div class="flex justify-between items-start mb-2">
                    <h4 class="font-semibold text-gray-800">Admin</h4>
                    <span class="text-sm text-gray-600">{{ $fb->tanggal ? \Carbon\Carbon::parse($fb->tanggal)->format('d/m/Y H:i') : '-' }}</span>
                </div>
                <p class="text-gray-700">{{ $fb->isi }}</p>
            </div>
            @endforeach
        </div>
        @else
        <p class="text-gray-600 mb-6">Belum ada feedback dari admin</p>
        @endif

        <!-- Add Feedback (Admin Only) -->
        @if(Auth::user()->isAdmin())
        <div class="border-t pt-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Tambah Feedback</h3>
            <form action="{{ route('pengaduan.addFeedback', $pengaduan) }}" method="POST">
                @csrf
                <div class="mb-4">
                    <textarea name="isi" rows="3" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 @error('isi') border-red-500 @enderror" placeholder="Tulis feedback Anda..." required></textarea>
                    @error('isi')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                    @enderror
                </div>
                <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                    <i class="fas fa-paper-plane"></i> Kirim Feedback
                </button>
            </form>
        </div>
        @endif
    </div>
</div>
@endsection
