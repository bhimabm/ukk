@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4 py-8">
    <!-- Header -->
    <div class="mb-8">
        <div class="flex justify-between items-center">
            <div>
                <h1 class="text-3xl font-bold text-gray-800">Daftar Pengaduan</h1>
            </div>
            @if(!Auth::user()->isAdmin())
            <a href="{{ route('pengaduan.create') }}" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                <i class="fas fa-plus"></i> Buat Pengaduan Baru
            </a>
            @endif
        </div>
    </div>

    <!-- Alert Messages -->
    @if(session('success'))
    <div class="mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded">
        {{ session('success') }}
    </div>
    @endif

    @if(session('error'))
    <div class="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded">
        {{ session('error') }}
    </div>
    @endif

    <!-- Pengaduan Table -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-100 border-b">
                    <tr>
                        <th class="px-4 py-3 text-left">Tanggal</th>
                        @if(Auth::user()->isAdmin())
                        <th class="px-4 py-3 text-left">Siswa</th>
                        @endif
                        <th class="px-4 py-3 text-left">Kategori</th>
                        <th class="px-4 py-3 text-left">Lokasi</th>
                        <th class="px-4 py-3 text-left">Keterangan</th>
                        <th class="px-4 py-3 text-left">Status</th>
                        <th class="px-4 py-3 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($pengaduan as $item)
                    <tr class="border-b hover:bg-gray-50">
                        <td class="px-4 py-3 whitespace-nowrap">{{ $item->tanggal ? \Carbon\Carbon::parse($item->tanggal)->format('d/m/Y') : '-' }}</td>
                        @if(Auth::user()->isAdmin())
                        <td class="px-4 py-3">{{ optional($item->user)->name ?? '-' }}</td>
                        @endif
                        <td class="px-4 py-3">{{ optional($item->kategori)->nama ?? '-' }}</td>
                        <td class="px-4 py-3">{{ $item->lokasi }}</td>
                        <td class="px-4 py-3">{{ \Illuminate\Support\Str::limit($item->keterangan, 30) }}</td>
                        <td class="px-4 py-3">
                            <span class="px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap
                                @if($item->status == 'Menunggu') bg-yellow-100 text-yellow-800
                                @elseif($item->status == 'Proses') bg-orange-100 text-orange-800
                                @else bg-green-100 text-green-800
                                @endif">
                                {{ $item->status }}
                            </span>
                        </td>
                        <td class="px-4 py-3 text-center">
                            <a href="{{ route('pengaduan.show', $item) }}" class="text-blue-500 hover:text-blue-700" title="Lihat">
                                <i class="fas fa-eye"></i>
                            </a>
                            @if(!Auth::user()->isAdmin() && $item->status == 'Menunggu')
                            <a href="{{ route('pengaduan.edit', $item) }}" class="text-yellow-500 hover:text-yellow-700 ml-2" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="{{ route('pengaduan.destroy', $item) }}" method="POST" class="inline" onsubmit="return confirm('Yakin ingin menghapus?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-red-500 hover:text-red-700 ml-2" title="Hapus">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="{{ Auth::user()->isAdmin() ? 7 : 6 }}" class="px-4 py-3 text-center text-gray-600">
                            Belum ada pengaduan
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        @if($pengaduan->hasPages())
        <div class="px-4 py-3 bg-gray-50 border-t">
            {{ $pengaduan->links() }}
        </div>
        @endif
    </div>
</div>
@endsection
