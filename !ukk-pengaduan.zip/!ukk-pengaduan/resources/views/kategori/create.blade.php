@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4 py-8 max-w-2xl">
    <!-- Header -->
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-800">Tambah Kategori Baru</h1>
        <p class="text-gray-600">Buat kategori pengaduan baru untuk siswa</p>
    </div>

    <!-- Form -->
    <div class="bg-white rounded-lg shadow-md p-6">
        <form action="{{ route('kategori.store') }}" method="POST">
            @csrf

            <!-- Nama Kategori -->
            <div class="mb-6">
                <label for="nama" class="block text-gray-700 font-semibold mb-2">Nama Kategori <span class="text-red-500">*</span></label>
                <input type="text" name="nama" id="nama" value="{{ old('nama') }}" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 @error('nama') border-red-500 @enderror" placeholder="Contoh: Kebersihan, Fasilitas, Guru, dll" required autofocus>
                @error('nama')
                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Form Actions -->
            <div class="flex gap-4">
                <button type="submit" class="flex-1 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                    <i class="fas fa-check"></i> Tambah Kategori
                </button>
                <a href="{{ route('kategori.index') }}" class="flex-1 bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded text-center">
                    <i class="fas fa-times"></i> Batal
                </a>
            </div>
        </form>
    </div>

    <!-- Info -->
    <div class="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
        <p class="text-sm text-yellow-700">
            <i class="fas fa-lightbulb"></i>
            <strong>Tips:</strong> Pilih nama kategori yang deskriptif dan mudah dipahami siswa. Contoh: "Kebersihan Ruang", "Fasilitas Belajar", "Sikap Guru", dll.
        </p>
    </div>
</div>
@endsection
