@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4 py-8">
    <!-- Header -->
    <div class="mb-8 flex justify-between items-center">
        <div>
            <h1 class="text-3xl font-bold text-gray-800">Dashboard Saya</h1>
            <p class="text-gray-600">Selamat datang, {{ Auth::user()->name }}</p>
        </div>
        <a href="{{ route('pengaduan.create') }}" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            <i class="fas fa-plus"></i> Buat Pengaduan Baru
        </a>
    </div>

    <!-- Statistics Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <!-- Total Pengaduan -->
        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-blue-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm">Total Pengaduan</p>
                    <p class="text-3xl font-bold text-blue-500">{{ $totalPengaduan }}</p>
                </div>
                <div class="text-blue-500 text-3xl">
                    <i class="fas fa-file-alt"></i>
                </div>
            </div>
        </div>

        <!-- Pengaduan Menunggu -->
        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-yellow-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm">Menunggu</p>
                    <p class="text-3xl font-bold text-yellow-500">{{ $pengaduanMenunggu }}</p>
                </div>
                <div class="text-yellow-500 text-3xl">
                    <i class="fas fa-clock"></i>
                </div>
            </div>
        </div>

        <!-- Pengaduan Proses -->
        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-orange-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm">Proses</p>
                    <p class="text-3xl font-bold text-orange-500">{{ $pengaduanProses }}</p>
                </div>
                <div class="text-orange-500 text-3xl">
                    <i class="fas fa-spinner"></i>
                </div>
            </div>
        </div>

        <!-- Pengaduan Selesai -->
        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-green-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm">Selesai</p>
                    <p class="text-3xl font-bold text-green-500">{{ $pengaduanSelesai }}</p>
                </div>
                <div class="text-green-500 text-3xl">
                    <i class="fas fa-check-circle"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Daftar Pengaduan -->
    <div class="bg-white rounded-lg shadow-md p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Pengaduan Saya</h2>
        
        @if(session('success'))
        <div class="mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded">
            {{ session('success') }}
        </div>
        @endif

        <div class="space-y-4">
            @forelse($pengaduan as $item)
            <div class="border rounded-lg p-4 hover:shadow-lg transition">
                <div class="flex justify-between items-start mb-3">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-800">{{ $item->kategori->nama }}</h3>
                        <p class="text-sm text-gray-600">
                            <i class="fas fa-map-marker-alt"></i> {{ $item->lokasi }}
                        </p>
                    </div>
                    <span class="px-3 py-1 rounded-full text-xs font-semibold
                        @if($item->status == 'Menunggu') bg-yellow-100 text-yellow-800
                        @elseif($item->status == 'Proses') bg-orange-100 text-orange-800
                        @else bg-green-100 text-green-800
                        @endif">
                        {{ $item->status }}
                    </span>
                </div>

                <p class="text-gray-700 mb-3">{{ Str::limit($item->keterangan, 100) }}</p>

                <div class="flex justify-between items-center text-sm text-gray-600">
                    <span>
                        <i class="fas fa-calendar"></i> {{ $item->tanggal->format('d/m/Y H:i') }}
                    </span>
                    @if($item->feedback->count() > 0)
                    <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded">
                        <i class="fas fa-comments"></i> {{ $item->feedback->count() }} Feedback
                    </span>
                    @endif
                </div>

                <div class="mt-3 flex gap-2">
                    <a href="{{ route('pengaduan.show', $item) }}" class="text-blue-500 hover:text-blue-700 font-semibold text-sm">
                        <i class="fas fa-eye"></i> Lihat Detail
                    </a>
                    @if($item->status == 'Menunggu')
                    <a href="{{ route('pengaduan.edit', $item) }}" class="text-yellow-500 hover:text-yellow-700 font-semibold text-sm">
                        <i class="fas fa-edit"></i> Edit
                    </a>
                    <form action="{{ route('pengaduan.destroy', $item) }}" method="POST" class="inline" onsubmit="return confirm('Yakin ingin menghapus?')">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="text-red-500 hover:text-red-700 font-semibold text-sm">
                            <i class="fas fa-trash"></i> Hapus
                        </button>
                    </form>
                    @endif
                </div>
            </div>
            @empty
            <div class="text-center py-8">
                <p class="text-gray-600 mb-4">Anda belum membuat pengaduan</p>
                <a href="{{ route('pengaduan.create') }}" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded inline-block">
                    <i class="fas fa-plus"></i> Buat Pengaduan Pertama Anda
                </a>
            </div>
            @endforelse
        </div>

        @if($pengaduan->hasPages())
        <div class="mt-6">
            {{ $pengaduan->links() }}
        </div>
        @endif
    </div>
</div>
@endsection
