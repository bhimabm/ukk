<?php

namespace App\Http\Controllers;

use App\Models\Pengaduan;
use App\Models\Kategori;
use App\Models\Feedback;
use App\Models\User;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        /** @var User $user */
        $user = auth()->user();

        if ($user->isAdmin()) {
            return $this->adminDashboard();
        } else {
            return $this->siswaDashboard();
        }
    }

    private function adminDashboard()
    {
        // Statistik Pengaduan
        $totalPengaduan = Pengaduan::count();
        $pengaduanMenunggu = Pengaduan::where('status', 'Menunggu')->count();
        $pengaduanProses = Pengaduan::where('status', 'Proses')->count();
        $pengaduanSelesai = Pengaduan::where('status', 'Selesai')->count();

        // Total Siswa
        $totalSiswa = User::where('is_admin', 0)->count();

        // Data untuk grafik - Pengaduan per kategori
        $pengaduanPerKategori = Kategori::withCount('pengaduan')
            ->get()
            ->map(function ($item) {
                return [
                    'nama' => $item->nama,
                    'count' => $item->pengaduan_count
                ];
            });

        // Data Pengaduan Terbaru
        $pengaduanTerbaru = Pengaduan::with(['user', 'kategori'])
            ->orderBy('tanggal', 'desc')
            ->take(5)
            ->get();

        // Statistik Status
        $statusData = [
            'Menunggu' => $pengaduanMenunggu,
            'Proses' => $pengaduanProses,
            'Selesai' => $pengaduanSelesai
        ];

        return view('dashboard.admin', [
            'totalPengaduan' => $totalPengaduan,
            'pengaduanMenunggu' => $pengaduanMenunggu,
            'pengaduanProses' => $pengaduanProses,
            'pengaduanSelesai' => $pengaduanSelesai,
            'totalSiswa' => $totalSiswa,
            'pengaduanPerKategori' => $pengaduanPerKategori,
            'pengaduanTerbaru' => $pengaduanTerbaru,
            'statusData' => $statusData
        ]);
    }

    private function siswaDashboard()
    {
        /** @var User $user */
        $user = auth()->user();

        // Pengaduan Siswa dengan pagination
        $pengaduanSiswa = $user->pengaduan()
            ->with(['kategori', 'feedback'])
            ->orderBy('tanggal', 'desc')
            ->paginate(10);

        // Statistik Pengaduan Siswa - hitung dari semua data
        $allPengaduan = $user->pengaduan()->get();
        $totalPengaduan = $allPengaduan->count();
        $pengaduanMenunggu = $allPengaduan->where('status', 'Menunggu')->count();
        $pengaduanProses = $allPengaduan->where('status', 'Proses')->count();
        $pengaduanSelesai = $allPengaduan->where('status', 'Selesai')->count();

        return view('dashboard.siswa', [
            'pengaduan' => $pengaduanSiswa,
            'totalPengaduan' => $totalPengaduan,
            'pengaduanMenunggu' => $pengaduanMenunggu,
            'pengaduanProses' => $pengaduanProses,
            'pengaduanSelesai' => $pengaduanSelesai,
        ]);
    }
}
