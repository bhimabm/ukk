<?php

namespace App\Http\Controllers;

use App\Models\Kategori;
use Illuminate\Http\Request;

class KategoriController extends Controller
{
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            /** @var \\App\\Models\\User|null $authUser */
            $authUser = auth()->user();

            if (!$authUser || !$authUser->isAdmin()) {
                return redirect()->route('dashboard')->with('error', 'Anda tidak memiliki akses ke halaman ini');
            }

            return $next($request);
        });
    }

    public function index()
    {
        $kategori = Kategori::with('pengaduan')->get();
        return view('kategori.index', compact('kategori'));
    }

    public function create()
    {
        return view('kategori.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama' => 'required|string|max:45|unique:kategori,nama',
        ]);

        Kategori::create($validated);

        return redirect()->route('kategori.index')->with('success', 'Kategori berhasil ditambahkan');
    }

    public function edit(Kategori $kategori)
    {
        return view('kategori.edit', compact('kategori'));
    }

    public function update(Request $request, Kategori $kategori)
    {
        $validated = $request->validate([
            'nama' => 'required|string|max:45|unique:kategori,nama,' . $kategori->id,
        ]);

        $kategori->update($validated);

        return redirect()->route('kategori.index')->with('success', 'Kategori berhasil diubah');
    }

    public function destroy(Kategori $kategori)
    {
        // Cek apakah kategori sudah memiliki pengaduan
        if ($kategori->pengaduan()->count() > 0) {
            return redirect()->route('kategori.index')->with('error', 'Tidak bisa menghapus kategori yang sudah memiliki pengaduan');
        }

        $kategori->delete();

        return redirect()->route('kategori.index')->with('success', 'Kategori berhasil dihapus');
    }
}
