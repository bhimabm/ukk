<?php

namespace App\Http\Controllers;

use App\Models\Pengaduan;
use App\Models\Kategori;
use App\Models\Feedback;
use Illuminate\Http\Request;

class PengaduanController extends Controller
{
    public function index()
    {
        /** @var \App\Models\User $authUser */
        $authUser = auth()->user();
        
        if ($authUser->isAdmin()) {
            $pengaduan = Pengaduan::with(['user', 'kategori', 'feedback'])
                ->orderBy('tanggal', 'desc')
                ->paginate(10);
        } else {
            $pengaduan = $authUser->pengaduan()
                ->with(['kategori', 'feedback'])
                ->orderBy('tanggal', 'desc')
                ->paginate(10);
        }

        return view('pengaduan.index', compact('pengaduan'));
    }

    public function create()
    {
        /** @var \App\Models\User $authUser */
        $authUser = auth()->user();
        
        if ($authUser->isAdmin()) {
            return redirect()->route('pengaduan.index')->with('error', 'Anda tidak bisa membuat pengaduan');
        }

        $kategori = Kategori::all();
        return view('pengaduan.create', compact('kategori'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'kategori_id' => 'required|exists:kategori,id',
            'lokasi' => 'required|string|max:45',
            'keterangan' => 'required|string',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $validated['user_id'] = auth()->id();
        $validated['tanggal'] = now();
        $validated['status'] = 'Menunggu';

        if ($request->hasFile('foto')) {
            $file = $request->file('foto');
            $filename = time() . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('uploads/pengaduan'), $filename);
            $validated['foto'] = $filename;
        }

        Pengaduan::create($validated);

        return redirect()->route('pengaduan.index')->with('success', 'Pengaduan berhasil dibuat');
    }

    public function show(Pengaduan $pengaduan)
    {
        /** @var \App\Models\User $authUser */
        $authUser = auth()->user();
        
        // Check if user owns the pengaduan or is admin
        if (!$authUser->isAdmin() && $pengaduan->user_id != auth()->id()) {
            return redirect()->route('dashboard')->with('error', 'Anda tidak bisa melihat pengaduan ini');
        }

        $pengaduan->load(['user', 'kategori', 'feedback']);
        return view('pengaduan.show', compact('pengaduan'));
    }

    public function edit(Pengaduan $pengaduan)
    {
        /** @var \App\Models\User $authUser */
        $authUser = auth()->user();
        
        if (!$authUser->isAdmin() && $pengaduan->user_id != auth()->id()) {
            return redirect()->route('pengaduan.index')->with('error', 'Anda tidak bisa mengedit pengaduan ini');
        }

        // Hanya bisa edit jika status Menunggu
        if ($pengaduan->status != 'Menunggu') {
            return redirect()->route('pengaduan.show', $pengaduan)->with('error', 'Pengaduan sudah tidak bisa diubah');
        }

        $kategori = Kategori::all();
        return view('pengaduan.edit', compact('pengaduan', 'kategori'));
    }

    public function update(Request $request, Pengaduan $pengaduan)
    {
        /** @var \App\Models\User $authUser */
        $authUser = auth()->user();
        
        if (!$authUser->isAdmin() && $pengaduan->user_id != auth()->id()) {
            return redirect()->route('pengaduan.index')->with('error', 'Anda tidak bisa mengubah pengaduan ini');
        }

        if ($pengaduan->status != 'Menunggu') {
            return redirect()->route('pengaduan.show', $pengaduan)->with('error', 'Pengaduan sudah tidak bisa diubah');
        }

        $validated = $request->validate([
            'kategori_id' => 'required|exists:kategori,id',
            'lokasi' => 'required|string|max:45',
            'keterangan' => 'required|string',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        if ($request->hasFile('foto')) {
            // Delete old photo
            if ($pengaduan->foto && file_exists(public_path('uploads/pengaduan/' . $pengaduan->foto))) {
                unlink(public_path('uploads/pengaduan/' . $pengaduan->foto));
            }

            $file = $request->file('foto');
            $filename = time() . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('uploads/pengaduan'), $filename);
            $validated['foto'] = $filename;
        }

        $pengaduan->update($validated);

        return redirect()->route('pengaduan.show', $pengaduan)->with('success', 'Pengaduan berhasil diubah');
    }

    public function destroy(Pengaduan $pengaduan)
    {
        /** @var \App\Models\User $authUser */
        $authUser = auth()->user();
        
        if (!$authUser->isAdmin() && $pengaduan->user_id != auth()->id()) {
            return redirect()->route('pengaduan.index')->with('error', 'Anda tidak bisa menghapus pengaduan ini');
        }

        if ($pengaduan->status != 'Menunggu') {
            return redirect()->route('pengaduan.show', $pengaduan)->with('error', 'Pengaduan sudah tidak bisa dihapus');
        }

        if ($pengaduan->foto && file_exists(public_path('uploads/pengaduan/' . $pengaduan->foto))) {
            unlink(public_path('uploads/pengaduan/' . $pengaduan->foto));
        }

        $pengaduan->delete();

        return redirect()->route('pengaduan.index')->with('success', 'Pengaduan berhasil dihapus');
    }

    // Admin hanya
    public function updateStatus(Request $request, Pengaduan $pengaduan)
    {
        /** @var \App\Models\User $authUser */
        $authUser = auth()->user();
        
        if (!$authUser->isAdmin()) {
            return redirect()->route('pengaduan.index')->with('error', 'Anda tidak memiliki akses');
        }

        $validated = $request->validate([
            'status' => 'required|in:Menunggu,Proses,Selesai',
        ]);

        $pengaduan->update($validated);

        return redirect()->route('pengaduan.show', $pengaduan)->with('success', 'Status pengaduan berhasil diubah');
    }

    public function addFeedback(Request $request, Pengaduan $pengaduan)
    {
        /** @var \App\Models\User $authUser */
        $authUser = auth()->user();
        
        if (!$authUser->isAdmin()) {
            return redirect()->route('pengaduan.show', $pengaduan)->with('error', 'Anda tidak memiliki akses');
        }

        $validated = $request->validate([
            'isi' => 'required|string|max:255',
        ]);

        $validated['pengaduan_id'] = $pengaduan->id;
        $validated['tanggal'] = now();

        Feedback::create($validated);

        return redirect()->route('pengaduan.show', $pengaduan)->with('success', 'Feedback berhasil ditambahkan');
    }
}
